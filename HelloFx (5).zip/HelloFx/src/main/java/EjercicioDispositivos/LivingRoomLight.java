package EjercicioDispositivos;

import java.util.ArrayList;
import java.util.List;

public class LivingRoomLight extends Light implements ObservableDevice {
    private static LivingRoomLight instance; // Agregar una instancia única de LivingRoomLight

    private List<Observer> deviceObservers = new ArrayList<>();

    private LivingRoomLight(String location) {
        super(location); // Llamar al constructor de la superclase Light
    }

    public static LivingRoomLight getInstance(String location) {
        if (instance == null) {
            instance = new LivingRoomLight(location);
        }
        return instance;
    }

    @Override
    public void addObserver(Observer observer) {
        deviceObservers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        deviceObservers.remove(observer);
    }

    @Override
    public void notifyObservers(boolean isOn) {
        for (Observer observer : deviceObservers) {
            observer.update(new DeviceState("Living Room Light", isOn));
        }
    }
}
