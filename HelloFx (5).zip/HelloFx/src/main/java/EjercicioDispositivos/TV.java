package EjercicioDispositivos;

import java.util.ArrayList;
import java.util.List;

public class TV implements ObservableDevice {
    private String location;
    private boolean isOn;
    private List<Observer> observers = new ArrayList<>();
    private static TV instance; // Instancia única de TV
    private boolean previousState;

    private TV(String location) {
        this.location = location;
        this.isOn = false;
    }

    // Método para obtener la instancia única de TV
    public static TV getInstance(String location) {
        if (instance == null) {
            instance = new TV(location);
        }
        return instance;
    }

    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    public void notifyObservers(boolean isOn) {
        for (Observer observer : observers) {
            observer.update(new DeviceState("TV", isOn));
        }
    }

    public void turnOn() {
        // Almacena el estado anterior
        previousState = isOn;
        isOn = true;
        System.out.println(location + " TV is On");
        notifyObservers(true);
    }

    public void turnOff() {
        // Almacena el estado anterior
        previousState = isOn;
        isOn = false;
        System.out.println(location + " TV is Off");
        notifyObservers(false);
    }


}
