package EjercicioDispositivos;

import java.util.ArrayList;
import java.util.List;

public class Hottub implements ObservableDevice {
    private String location;
    private boolean isOn;
    private List<Observer> observers = new ArrayList<>();
    private static Hottub instance; // Instancia única de CeilingFan
    private boolean previousState;

    private Hottub(String location) {
        this.location = location;
        this.isOn = false;
    }

    // Método para obtener la instancia única de CeilingFan
    public static Hottub getInstance(String location) {
        if (instance == null) {
            instance = new Hottub(location);
        }
        return instance;
    }

    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    public void notifyObservers(boolean isOn) {
        for (Observer observer : observers) {
            observer.update(new DeviceState("Hottub", isOn));
        }
    }

    public void turnOn() {
        // Almacena el estado anterior
        previousState = isOn;
        isOn = true;
        System.out.println(location + " Hottub is On");
        notifyObservers(true);
    }

    public void turnOff() {
        // Almacena el estado anterior
        previousState = isOn;
        isOn = false;
        System.out.println(location + " Hottub is Off");
        notifyObservers(false);
    }


}
