package EjercicioDispositivos;

// Interfaz para observar las luces
interface LightObserver {
    void updateLight(boolean isOn);
}
