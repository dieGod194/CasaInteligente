package EjercicioDispositivos;

import java.util.ArrayList;
import java.util.List;

public class EntranceLights extends Light implements ObservableDevice {
    private static EntranceLights instance; // Agregar una instancia única de LivingRoomLight

    private List<Observer> deviceObservers = new ArrayList<>();

    private EntranceLights(String location) {
        super(location); // Llamar al constructor de la superclase Light
    }

    public static EntranceLights getInstance(String location) {
        if (instance == null) {
            instance = new EntranceLights(location);
        }
        return instance;
    }

    @Override
    public void addObserver(Observer observer) {
        deviceObservers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        deviceObservers.remove(observer);
    }

    @Override
    public void notifyObservers(boolean isOn) {
        for (Observer observer : deviceObservers) {
            observer.update(new DeviceState("Entrance Lights", isOn));
        }
    }
}
