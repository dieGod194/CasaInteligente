package EjercicioDispositivos;

public class DeviceState {
    private String deviceName;
    private boolean isOn;

    public DeviceState(String deviceName, boolean isOn) {
        this.deviceName = deviceName;
        this.isOn = isOn;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public boolean isOn() {
        return isOn;
    }


}
