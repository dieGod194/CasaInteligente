package EjercicioDispositivos;

import java.util.ArrayList;
import java.util.List;


// Clase Light que implementa ObservableDevice
public class Light implements ObservableDevice {
    private String location;
    private boolean isOn;
    private List<Observer> deviceObservers = new ArrayList<>();
    private List<LightObserver> lightObservers = new ArrayList<>();

    public Light(String location) {
        this.location = location;
        this.isOn = false;
    }


    @Override
    public void addObserver(Observer observer) {
        deviceObservers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        deviceObservers.remove(observer);
    }

    @Override
    public void notifyObservers(boolean isOn) {
        for (Observer observer : deviceObservers) {
            observer.update(new DeviceState("Light", isOn));
        }
    }


    // Método para notificar a los observadores de luces
    public void notifyLightObservers(boolean isOn) {
        for (LightObserver observer : lightObservers) {
            observer.updateLight(isOn);
        }
    }

    public void turnOn() {
        isOn = true;
        System.out.println(location + " Light is now ON");
        notifyObservers(true);
        notifyLightObservers(true);
    }

    public void turnOff() {
        isOn = false;
        System.out.println(location + " Light is now OFF");
        notifyObservers(false);
        notifyLightObservers(false);
    }
}
