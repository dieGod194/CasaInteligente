package EjercicioDispositivos;

public interface Observer {
    void update(DeviceState deviceState);
}
