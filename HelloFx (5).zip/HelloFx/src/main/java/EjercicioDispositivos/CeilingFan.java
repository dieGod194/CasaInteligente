package EjercicioDispositivos;

import java.util.ArrayList;
import java.util.List;

public class CeilingFan implements ObservableDevice {
    private String location;
    private boolean isOn;
    private List<Observer> observers = new ArrayList<>();
    private static CeilingFan instance; // Instancia única de CeilingFan

    private boolean previousState; // Nuevo campo para el estado anterior

    private CeilingFan(String location) {
        this.location = location;
        this.isOn = false;
    }

    // Método para obtener la instancia única de CeilingFan
    public static CeilingFan getInstance(String location) {
        if (instance == null) {
            instance = new CeilingFan(location);
        }
        return instance;
    }

    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    public void notifyObservers(boolean isOn) {
        for (Observer observer : observers) {
            observer.update(new DeviceState("Ceiling Fan", isOn));
        }
    }


    public void turnOn() {
        // Almacena el estado anterior
        previousState = isOn;
        isOn = true;
        System.out.println(location + " Ceiling Fan is On");
        notifyObservers(true);
    }

    public void turnOff() {
        // Almacena el estado anterior
        previousState = isOn;
        isOn = false;
        System.out.println(location + " Ceiling Fan is Off");
        notifyObservers(false);
    }

}
