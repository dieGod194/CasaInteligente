package EjercicioDispositivos;

public interface ObservableDevice {
    void addObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers(boolean isOn);
}
