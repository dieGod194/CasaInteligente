package com.example.hellofx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;



public class HelloApplication extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Cargar la interfaz de HelloController
        FXMLLoader helloLoader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent helloRoot = helloLoader.load();
        Scene helloScene = new Scene(helloRoot);
        primaryStage.setTitle("Hello!");
        primaryStage.setScene(helloScene);

        // Crear una segunda ventana (interfaz window1Controller)
        Stage secondStage = new Stage();
        FXMLLoader window1Loader = new FXMLLoader(getClass().getResource("window1.fxml"));
        Parent window1Root = window1Loader.load();
        Scene window1Scene = new Scene(window1Root);
        secondStage.setTitle("Window 1");
        secondStage.setScene(window1Scene);

        // Crear y configurar los controladores
        HelloController helloController = helloLoader.getController();
        window1Controller window1Controller = window1Loader.getController();
        helloController.setWindow1Controller(window1Controller);

        // Mostrar ambas ventanas
        primaryStage.show();
        secondStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
