package com.example.hellofx;

import EjercicioDispositivos.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.application.Platform;


public class window1Controller extends Application implements Observer {

    @FXML
    private Label ceilingFanLabel;

    @FXML
    private TextField ceilingfan;

    @FXML
    private TextField entrance;

    @FXML
    private Label entranceLightsLabel;

    @FXML
    private TextField garage;

    @FXML
    private Label garageDoorLabel;

    @FXML
    private TextField hottub;

    @FXML
    private Label hottubLabel;

    @FXML
    private TextField living;

    @FXML
    private Label livingRoomLightLabel;

    @FXML
    private TextField stereo;

    @FXML
    private Label stereoLabel;

    @FXML
    private TextField tv;

    @FXML
    private Label tvLabel;

    @FXML
    private TextField securitycamera;



    private Color javafxGreen = Color.GREEN;

    private DeviceState ceilingFanState;
    private DeviceState garageDoorState;
    private DeviceState hottubState;
    private DeviceState stereoState;
    private DeviceState tvState;
    private DeviceState livingRoomLightState;
    private DeviceState entranceLightsState;
    private DeviceState securityCameraState;
    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("window1.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root, 800, 600);
        primaryStage.setTitle("JavaFX Application");
        primaryStage.setScene(scene);
        primaryStage.show();

        // Configurar observadores
        CeilingFan.getInstance("Ceiling Fan").addObserver(this);
        GarageDoor.getInstance("GarageDoor").addObserver(this);
        Hottub.getInstance("Hottub").addObserver(this);
        Stereo.getInstance("Stereo").addObserver(this);
        TV.getInstance("TV").addObserver(this);
        LivingRoomLight.getInstance("Living Room Light").addObserver(this);
        EntranceLights.getInstance("Entrance Lights").addObserver(this);
        SecurityCamera.getInstance("Security Camera").addObserver(this);
    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void update(DeviceState deviceState) {
        Platform.runLater(() -> {
            if (deviceState.getDeviceName().equals("Ceiling Fan")) {
                actualizarEstadoCeilingFan(deviceState.isOn());
            }
            if (deviceState.getDeviceName().equals("GarageDoor")) {
                actualizarEstadoGarage(deviceState.isOn());
            }
            if (deviceState.getDeviceName().equals("Hottub")) {
                actualizarEstadoHottub(deviceState.isOn());
            }
            if (deviceState.getDeviceName().equals("Stereo")) {
                actualizarEstadoStereo(deviceState.isOn());
            }
            if (deviceState.getDeviceName().equals("TV")) {
                actualizarEstadoTV(deviceState.isOn());
            }
            if (deviceState.getDeviceName().equals("Living Room Light")) {
                actualizarEstadoLightLivingRoom(deviceState.isOn());
            }
            if (deviceState.getDeviceName().equals("Entrance Lights")) {
                actualizarEstadoEntranceLights(deviceState.isOn());
            }
            if (deviceState.getDeviceName().equals("Security Camera")) {
                actualizarEstadoEntranceLights(deviceState.isOn());
            }
        });
    }

    public void actualizarEstadoCeilingFan(boolean isOn) {
        String status = isOn ? "Encendido" : "Apagado";
        ceilingfan.setText(status);
        // Cambiar el color de fondo
        BackgroundFill backgroundFill;
        if (isOn) {
            backgroundFill = new BackgroundFill(Color.GREEN, null, null);
        } else {
            backgroundFill = new BackgroundFill(Color.RED, null, null);
        }
        Background background = new Background(backgroundFill);
        ceilingfan.setBackground(background);
    }

    public void actualizarEstadoGarage(boolean isOn) {
        String status = isOn ? "Abierto" : " Cerrado";
        garage.setText(status);
        // Cambiar el color de fondo
        BackgroundFill backgroundFill;
        if (isOn) {
            backgroundFill = new BackgroundFill(Color.GREEN, null, null);
        } else {
            backgroundFill = new BackgroundFill(Color.RED, null, null);
        }
        Background background = new Background(backgroundFill);
        garage.setBackground(background);
    }

    public void actualizarEstadoHottub(boolean isOn) {
        String status = isOn ? "Encendido" : "Apagado";
        hottub.setText(status);
        // Cambiar el color de fondo
        BackgroundFill backgroundFill;
        if (isOn) {
            backgroundFill = new BackgroundFill(Color.GREEN, null, null);
        } else {
            backgroundFill = new BackgroundFill(Color.RED, null, null);
        }
        Background background = new Background(backgroundFill);
        hottub.setBackground(background);
    }

    public void actualizarEstadoStereo(boolean isOn) {
        String status = isOn ? "Encendido" : "Apagado";
        stereo.setText(status);
        // Cambiar el color de fondo
        BackgroundFill backgroundFill;
        if (isOn) {
            backgroundFill = new BackgroundFill(Color.GREEN, null, null);
        } else {
            backgroundFill = new BackgroundFill(Color.RED, null, null);
        }
        Background background = new Background(backgroundFill);
        stereo.setBackground(background);
    }

    public void actualizarEstadoTV(boolean isOn) {
        String status = isOn ? "Encendido" : "Apagado";
        tv.setText(status);
        // Cambiar el color de fondo
        BackgroundFill backgroundFill;
        if (isOn) {
            backgroundFill = new BackgroundFill(Color.GREEN, null, null);
        } else {
            backgroundFill = new BackgroundFill(Color.RED, null, null);
        }
        Background background = new Background(backgroundFill);
        tv.setBackground(background);
    }

    public void actualizarEstadoLightLivingRoom(boolean isOn) {
        String status = isOn ? "Encendido" : "Apagado";
        living.setText(status);
        // Cambiar el color de fondo
        BackgroundFill backgroundFill;
        if (isOn) {
            backgroundFill = new BackgroundFill(Color.GREEN, null, null);
        } else {
            backgroundFill = new BackgroundFill(Color.RED, null, null);
        }
        Background background = new Background(backgroundFill);
        living.setBackground(background);
    }

    public void actualizarEstadoEntranceLights(boolean isOn) {

        String status = isOn ? "Encendido" : "Apagado";
        entrance.setText(status);
        // Cambiar el color de fondo
        BackgroundFill backgroundFill;
        if (isOn) {
            backgroundFill = new BackgroundFill(Color.GREEN, null, null);
        } else {
            backgroundFill = new BackgroundFill(Color.RED, null, null);
        }
        Background background = new Background(backgroundFill);
        entrance.setBackground(background);
    }


    public void actualizarEstadoSecurityCamera(boolean isOn) {

        String status = isOn ? "Encendido" : "Apagado";
        securitycamera.setText(status);
        // Cambiar el color de fondo
        BackgroundFill backgroundFill;
        if (isOn) {
            backgroundFill = new BackgroundFill(Color.GREEN, null, null);
        } else {
            backgroundFill = new BackgroundFill(Color.RED, null, null);
        }
        Background background = new Background(backgroundFill);
        securitycamera.setBackground(background);
    }
    

    public void tvTextField(ActionEvent actionEvent)
    {

    }

    public void ceilingFanTextField(ActionEvent actionEvent) {
    }

    public void livingRoomLightTextField(ActionEvent actionEvent) {
    }

    public void entranceLightsTextField(ActionEvent actionEvent) {
    }

    public void garageDoorTextField(ActionEvent actionEvent) {
    }

    public void stereoTextField(ActionEvent actionEvent) {
    }

    public void hottubTextField(ActionEvent actionEvent) {
    }

    public void securitycameraTextField(ActionEvent actionEvent) {
    }


}