package com.example.hellofx;

import EjercicioDispositivos.*;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;

import javax.swing.*;
import java.util.Calendar;
import java.util.Stack;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import java.util.Calendar;



public class HelloController implements Observer {

    private Timeline colorChangeTimeline; // La instancia de Timeline

    private window1Controller window1Controller; // Agrega una referencia a window1Controller

    public void setWindow1Controller(window1Controller controller) {
        this.window1Controller = controller;
    }



    @FXML
    private Button GarageOff;

    @FXML
    private Button GarageOn;

    @FXML
    private Button Jacuzzi;

    @FXML
    private Button Jacuzziapagado;

    @FXML
    private Button LingromOn;

    @FXML
    private Button Lucesentradaon;

    @FXML
    private Button StereoApagado;

    @FXML
    private Button StereoEncendido;

    @FXML
    private Button TvOn;

    @FXML
    private Button VentiladorEncendido;

    @FXML
    private Button livingroomOff;

    @FXML
    private Button lucesentradaoff;

    @FXML
    private Button tvapagado;

    @FXML
    private Button undo;

    @FXML
    private Button ventiladorapagado;

    @FXML
    private Button fueraCasa;

    @FXML
    private Button SecurityOn;

    @FXML
    private Button SecurityOff;


    private Stack<Runnable> commandHistory = new Stack<>();
    private Stack<Runnable> rutina = new Stack<>();






    /// instancias
    CeilingFan ceilingFan = CeilingFan.getInstance("Ceiling Fan");
    GarageDoor garageDoor = GarageDoor.getInstance("Garage Door");
    Hottub hottub = Hottub.getInstance("Hottub");
    Stereo stereo = Stereo.getInstance("Stereo"); // Inicializar el dispositivo Stereo
    TV tv  = TV.getInstance("Tv");
    LivingRoomLight livingRoomLight = LivingRoomLight.getInstance("Living Room Light");
    EntranceLights entranceLights = EntranceLights.getInstance("Entrance Lights");

    SecurityCamera securityCamera = SecurityCamera.getInstance("Security Camera");



    BackgroundFill backgroundFill = new BackgroundFill(Color.GREEN, null, null);
    Background background = new Background(backgroundFill);

    @FXML
    void CeilingFanoffButton(ActionEvent event) {
        ceilingFan.turnOff();
        commandHistory.push(() -> {
            ceilingFan.turnOn();
            window1Controller.actualizarEstadoCeilingFan(true);


        });
        window1Controller.actualizarEstadoCeilingFan(false);
    }

    @FXML
    void CeilingFanonButton(ActionEvent event) {
        ceilingFan.turnOn();
        commandHistory.push(() -> {
            ceilingFan.turnOff();
            window1Controller.actualizarEstadoCeilingFan(false);
        });
        window1Controller.actualizarEstadoCeilingFan(true);
    }


    @FXML
    void GarageDoorOffButton1(ActionEvent event)
    {
        garageDoor.turnOff();
        commandHistory.push(() -> {
            garageDoor.turnOn();
            window1Controller.actualizarEstadoGarage(true);
        });
        window1Controller.actualizarEstadoGarage(false);
    }

    @FXML
    void GarageDoorOnButton(ActionEvent event)
    {
        garageDoor.turnOn();
        commandHistory.push(() -> {
            garageDoor.turnOff();
            window1Controller.actualizarEstadoGarage(false);
        });
        window1Controller.actualizarEstadoGarage(true);
    }

    @FXML
    void HottubOffButton2(ActionEvent event)
    {
        hottub.turnOff();
        commandHistory.push(() -> {
            hottub.turnOn();
            window1Controller.actualizarEstadoHottub(true);
        });
        window1Controller.actualizarEstadoHottub(false);
    }

    @FXML
    void HottubOnButton(ActionEvent event)
    {
        hottub.turnOn();
        commandHistory.push(() -> {
            hottub.turnOff();
            window1Controller.actualizarEstadoHottub(false);
        });
        window1Controller.actualizarEstadoHottub(true);
    }

    @FXML
    void LivingOffButton(ActionEvent event)
    {
        livingRoomLight.turnOff();
        commandHistory.push(() -> {
            livingRoomLight.turnOn();
            window1Controller.actualizarEstadoLightLivingRoom(true);
        });
        window1Controller.actualizarEstadoLightLivingRoom(false);
    }

    @FXML
    void LivingRoomOnButton(ActionEvent event)
    {
        livingRoomLight.turnOn();
        commandHistory.push(() -> {
            livingRoomLight.turnOff();
            window1Controller.actualizarEstadoLightLivingRoom(false);
        });
        window1Controller.actualizarEstadoLightLivingRoom(true);
    }

    @FXML
    void StereoOffButton4(ActionEvent event)
    {
        stereo.turnOff();
        commandHistory.push(() -> {
            stereo.turnOn();
            window1Controller.actualizarEstadoStereo(true);
        });
        window1Controller.actualizarEstadoStereo(false);
    }

    @FXML
    void StereoOnButton(ActionEvent event)
    {
        stereo.turnOff();
        commandHistory.push(() -> {
            stereo.turnOff();
            window1Controller.actualizarEstadoStereo(false);
        });
        window1Controller.actualizarEstadoStereo(true);
    }

    @FXML
    void TvOffButton5(ActionEvent event)
    {
        tv.turnOff();
        commandHistory.push(() -> {
            tv.turnOff();
            window1Controller.actualizarEstadoTV(true);
        });
        window1Controller.actualizarEstadoTV(false);
    }

    @FXML
    void TvOnButton(ActionEvent event)
    {
        tv.turnOn();
        commandHistory.push(() -> {
            tv.turnOff();
            window1Controller.actualizarEstadoTV(false);
        });
        window1Controller.actualizarEstadoTV(true);
    }

    @FXML
    void offButtonLightsEntrance(ActionEvent event)
    {
        entranceLights.turnOff();
        commandHistory.push(() -> {
            entranceLights.turnOn();
            window1Controller.actualizarEstadoEntranceLights(true);
        });
        window1Controller.actualizarEstadoEntranceLights(false);
    }

    @FXML
    void onButtonLightsEntrance(ActionEvent event)
    {
        entranceLights.turnOn();
        commandHistory.push(() -> {
            entranceLights.turnOff();
            window1Controller.actualizarEstadoEntranceLights(false);
        });
        window1Controller.actualizarEstadoEntranceLights(true);
    }


    public void onButtonSecurityCamera(ActionEvent actionEvent)
    {
        securityCamera.turnOn();
        commandHistory.push(() -> {
            securityCamera.turnOff();
            window1Controller.actualizarEstadoSecurityCamera(false);
        });
        window1Controller.actualizarEstadoSecurityCamera(true);

    }

    public void offButtonSecurityCamera(ActionEvent actionEvent)
    {
        securityCamera.turnOff();
        commandHistory.push(() -> {
            securityCamera.turnOn();
            window1Controller.actualizarEstadoSecurityCamera(true);
        });
        window1Controller.actualizarEstadoSecurityCamera(false);
    }

    @FXML
    void FueradeCasa(ActionEvent event) {
        String input = JOptionPane.showInputDialog("Ingresa la cantidad de días a simular:");

        try {
            int diasASimular = Integer.parseInt(input);

            // Limpiar la pila rutina
            rutina.clear();

            // Agregar las operaciones planificadas a la pila rutina
            for (int i = 0; i < diasASimular; i++) {
                // Agrega los comandos correspondientes para cada dispositivo en cada hora
                for (int hora = 1; hora <= 24; hora++)
                {
                    // Implementa la lógica para cada dispositivo en cada hora


                    rutina.push(() -> {
                        securityCamera.turnOff();
                        Platform.runLater(() -> window1Controller.actualizarEstadoSecurityCamera(false));

                    });

                    rutina.push(() -> {
                        System.out.println("No hay nada programado");
                    });

                    rutina.push(() -> {
                        System.out.println("No hay nada programado");
                    });

                    rutina.push(() -> {
                        System.out.println("No hay nada programado");
                    });

                    rutina.push(() -> {
                        entranceLights.turnOff();
                        Platform.runLater(() -> window1Controller.actualizarEstadoEntranceLights(false));

                    });

                    rutina.push(() -> {
                        System.out.println("No hay nada programado");
                    });

                    rutina.push(() -> {
                        livingRoomLight.turnOff();
                        Platform.runLater(() -> window1Controller.actualizarEstadoLightLivingRoom(false));

                    });

                    rutina.push(() -> {
                        System.out.println("No hay nada programado");
                    });

                    rutina.push(() -> {
                        System.out.println("No hay nada programado");
                    });

                    rutina.push(() -> {
                        stereo.turnOff();
                        Platform.runLater(() -> window1Controller.actualizarEstadoStereo(false));

                    });

                    rutina.push(() -> {
                        hottub.turnOff();
                        Platform.runLater(() -> window1Controller.actualizarEstadoHottub(false));

                    });

                    rutina.push(() -> {
                        System.out.println("No hay nada programado");
                    });

                    rutina.push(() -> {
                        System.out.println("No hay nada programado");
                    });

                    rutina.push(() -> {
                        hottub.turnOn();
                        Platform.runLater(() -> window1Controller.actualizarEstadoHottub(true));

                    });

                    rutina.push(() -> {
                        stereo.turnOn();
                        Platform.runLater(() -> window1Controller.actualizarEstadoStereo(true));

                    });

                    rutina.push(() -> {
                        tv.turnOff();
                        Platform.runLater(() -> window1Controller.actualizarEstadoTV(false));

                    });

                    rutina.push(() -> {
                        System.out.println("No hay nada programado");
                    });

                    rutina.push(() -> {
                        System.out.println("No hay nada programado");
                    });

                    rutina.push(() -> {
                        tv.turnOn();
                        Platform.runLater(() -> window1Controller.actualizarEstadoTV(true));

                    });

                    rutina.push(() -> {
                        livingRoomLight.turnOn();
                        Platform.runLater(() -> window1Controller.actualizarEstadoLightLivingRoom(true));

                    });

                    rutina.push(() -> {
                        System.out.println("No hay nada programado");
                    });

                    rutina.push(() -> {
                        System.out.println("No hay nada programado");
                    });

                    rutina.push(() -> {
                        entranceLights.turnOn();
                        Platform.runLater(() -> window1Controller.actualizarEstadoEntranceLights(true));

                    });

                    rutina.push(() -> {
                        garageDoor.turnOff();
                        Platform.runLater(() -> window1Controller.actualizarEstadoGarage(false));

                    });

                    rutina.push(() -> {
                        securityCamera.turnOn();
                        Platform.runLater(() -> window1Controller.actualizarEstadoSecurityCamera(true));

                    });

                    rutina.push(() -> {
                        System.out.println("No hay nada realizado a esta hora");
                    });

                }
            }

            // Crear un nuevo hilo para la simulación
            Thread simulationThread = new Thread(() -> {
                for (int dia = 1; dia <= diasASimular; dia++) {
                    System.out.println("Día " + dia + ":");

                    for (int hora = 1; hora <= 24; hora++) {
                        if (!rutina.isEmpty()) {
                            System.out.println("Hora " + hora);
                            Runnable lastCommand = rutina.pop();
                            lastCommand.run();
                        } else {
                            System.out.println("No hay más comandos programados para este día.");
                            break; // Salir del ciclo si no hay más comandos
                        }

                        // Esperar 2 segundos
                        try {
                            Thread.sleep(2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });

            simulationThread.start(); // Iniciar el hilo de simulación

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Debes ingresar un número válido para la cantidad de días.");
        }
    }




    @FXML
    void undoButton(ActionEvent event)
    {
        if (!commandHistory.isEmpty()) {
            Runnable lastCommand = commandHistory.pop();
            lastCommand.run();
            System.out.println("Deshaciendo la última acción.");
        } else {
            System.out.println("No hay acciones para deshacer.");
        }
    }

    @Override
    public void update(DeviceState deviceState) {
        if (deviceState.getDeviceName().equals("Ceiling Fan")) {
            boolean isCeilingFanOn = deviceState.isOn();
            if (isCeilingFanOn) {
                // El ventilador de techo está encendido, realiza la lógica correspondiente aquí
                System.out.println("El ventilador de techo está encendido.");
                // Puedes agregar más lógica si es necesario
            } else {
                // El ventilador de techo está apagado, realiza la lógica correspondiente aquí
                System.out.println("El ventilador de techo está apagado.");
                // Puedes agregar más lógica si es necesario
            }
        }
    }



}
